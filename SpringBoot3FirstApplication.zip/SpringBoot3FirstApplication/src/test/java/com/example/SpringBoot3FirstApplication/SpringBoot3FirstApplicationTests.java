package com.example.SpringBoot3FirstApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot3FirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
